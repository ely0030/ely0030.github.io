---
title: "a sense of renewed cool"
description: "I'm starting to think being relaxed is the productivity hack"
pubDate: 2025-07-03
pageType: literature2
category: thoughts
---

#### that Wu Wei magic

I'm starting to think being relaxed is the productivity hack

maybe that's the key
maybe that's the prerequisite

<br><br>
i always think of relaxing as a bad thing
as something that will get you caught off guard
and woken up months later wondering what the hell you did with your life

but maybe that's the key
to be so relaxed you can actually think about your life
as it happens to you