# NOTEPAD

*Raw thoughts have been processed and moved to priority list and old thoughts archive*

- The idea of a planning wall that clearly shows the projects I'm working on so i can plan stuff
The nice part is that I can fully visually design this virtual planning board

make it in the style of the site


C

---
# NOTEPAD

- when in the notepad the first time I click out of the editor it squashes all the newlines and fucks up the formatting. after that first time it doesnt happen anymore


- there's a random empty white space that keeps spawning in the notepad enter
when pressing enter, and at the start of the file


### Render Stuff
- make it so that it renders bulletlists in view mode