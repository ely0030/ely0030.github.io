- Ability to double click on an empty card spot and make a new card that way



- right now when a card gets vertically lower, in the vertical row the slots underneath that card go lower. this is very good.
a problem is that the slots to the left and right of it also get lower vertically when there's space for the card to go directly underneath a card there vertically

Can you make it so that the changes to the grid are contained within their vertical rows?






# A "project" (right now card is still referenced as a project some places) should actually be the entire configuration of cards. 

right now we just have one planning-wall with cards, and we just change that

I want there to be different "projects"/saves we can make and save

so for example, rn the planning-wall we have is the standard "project"

we could make a new "project" called gardening, and then when opening that all the cards would go away and we could start making cards for the gardening project. these'd be saved to its corresponding project.