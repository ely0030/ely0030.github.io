Use sequential thinking to think hard and out of the box, first principles style. Ultrathink on it, intelligently.

