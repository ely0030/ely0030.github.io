Give me a prompt for a fresh instance of you that has zero context of anything going on besides the handoff/blueprint file and your prompt

NOTES:

* mention the files needed, prepended with an @ at the end

