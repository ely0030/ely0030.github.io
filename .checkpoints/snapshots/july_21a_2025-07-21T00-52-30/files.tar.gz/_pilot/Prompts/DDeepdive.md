@claude.md @CLAUDE_INIT_PROMPT.md @docs/_START_HERE.md

Please do a deep dive on chat model user interface

I want you to really investigate and dig into the code and find out how everything works and why.

1st: find all the docs that can already give you some pointers  
2nd: look at all the related code and systemically map out everything  
3nd: write a doc file and put it in the corresponding doc folder under the correct documentation guidelines we've set in a file somewhere

---

utilize parallel agents to efficiently and intelligently go about this process.  
maybe make a sesssion folder/file within '/Users/chris/Desktop/2 CODEX/SESSIONS' to write down plans to keep clarity as you have something to cement and lay out your planning. update and tweak this session file as needed to keep you grounded and to hold reminders.

----

I've already done a little forework for you to help you, BUT, you still need to go through all the steps i've laid out.

FOREWORK:
