---
title: "On The Genealogy of Morals"
description: "by Nietszche"
pubDate: 2025-07-21T00:00:00.000Z
pageType: "literature2"
category: "book-reviews"
---

### thoughts:

on p.31

feels like cope a little. 

guy was born into aristocracy and is spending all his time trying to justify winning.
It's noticeable how he fan-cams aristocracy in an almost overtly biased way.
they do all these things that are so good and so pure. 

these things need evidence. 

I'm reading a lot of things of which I am doubtful.

aristocrats are never envious? They're always full of vitality and men of action? 

machiavelli painted a very different picture of the courts the elite inhabited..


it does read like a ton of glazing,
and I do get a sense that he's subconsciously biased towards aristocracy as he's one of them,

but whilst being unaware of the bias..