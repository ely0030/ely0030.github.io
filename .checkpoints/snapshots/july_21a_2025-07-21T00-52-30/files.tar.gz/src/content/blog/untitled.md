---
title: "untitled"
description: "untitled"
pubDate: 2025-07-17T00:00:00.000Z
pageType: "literature2"
category: "articles"
private: true
passwordHash: "2b266f5753f6deb012569bf887d3367c6ccd41fa0f1b1fb9189bc680edbb2073"
---

the natural state is things falling apart
 
every bit of effort you can put into things is you putting in energy to avoid something from disintegrating
 
 
all is endothermic
all living things are out to take your energy so that they don't run out of their own
 
that's just how it is
though sometimes it can be different
 
i'm here to be more than what the game has made me to be