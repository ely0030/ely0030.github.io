---
title: "my 10 fold path"
description: "the 10 fold path"
pubDate: 2025-07-13
pageType: literature2
category: manifestation
---



Settling for reality is stupid

why did i stoop to that?

what you see is all you know
what you know is all you want

if I don't dream, my world can only be so much

the dream of someone else
the dream of those who came before me

who is the dreamer?


---

my 10 fold path is this:

1. Gain massive insane amounts of money

Money is mana
money is power

money is the resources that allow you to scape your corner of the world, and perhaps even beyond that

for anybody that values their agency, that takes their life completely into their own hands and steps out into the world to mould into something as in the shape of their vision

power is key

the tibetans called it "nus pa", more precisely





---
the world doesn't love you
the world doesn't owe you

the world is a billion life form all together at once, trying to be alive
everything that's happened and will happen emerges from that

all the beliefs that help you sleep at night
that keep the economy turning
the jobs from going vacant
democracy from falling apart

from jesuits falling to sin because of their urges

it is all part of the game

the good
the bad
the neutral




---

# my 10 fold path:

1. Gain massive insane amounts of money
1.5 amass nus pa, amass competence, amass ability 

2. create great art

3. create spaces where you push the limits of what it means to be alive on earth in the history of the universe
leave out what is expected, what people settle for

define the rules. do NOT limit yourself, ever

stay in touch with reality, without being confined to it

explore the bounds of physics and the laws of things
exploit them, form them and manipulate them around

shape matter
construct the dream