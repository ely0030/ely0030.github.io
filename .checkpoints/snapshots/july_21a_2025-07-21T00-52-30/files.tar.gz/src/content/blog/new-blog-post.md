---
title: "New Blog Post"
description: "R"
pubDate: 2025-07-17T00:00:00.000Z
pageType: "blog"
category: "policy"
---

R is a "child".
 
in conversations with him he cannot take accountability whatsoever

his conversation style is a style of deflection and the avoiding and dodging of responsibility

his conversation style focuses on this:
- being combative and inflammatory in statements and phrases used

- when being confronted with this it's a pattern of denial, flipping it around on YOU as if you are the one doing it, or deflecting and guiding to whatever else you have been doing or he has been doing (misdirecting the argument as if you're targeting over something you didn't even mention) (you cannot argue with him based on logic)
- 

1. there's an anger and annoyance that gets very easily triggered and carelessly vented
- raising his voice, and strong eye contact with an "intimidating expression"
- slamming of doors or when placing down objects
(complete denial and/or unawareness of doing this as well)
- domineering conversation style with a lot of "YOU" statements and blame shifting



# Anecdotes
In one occasion I'm sitting around and I get asked what to eat tonight. I say I don't really mind much and mention getting Dominos pizza

After this I get completely painted as a lazy free loader which always gets served and treated like some kind of decadent royalty

I take offense at this and raise the subjects
- why are you painting me off like this while these are things we are planning together to have fun together? which I also work on and do a lot of solo effort for (i do put in effort to eloborately organize these things, but upon saying this I get told i did it only ONCE or never really which is objectively un-true)
It gets painted as if they organize this stuff purely for me. I retort "why are you painting it off like you don't enjoy elaborate "gezellig" moments?" It's completely surreal to me even writing this in hind-sight.

I point this out and it gets reacted to as if I am saying something ridiculous.



---

I find myself writing this file and into the wormhole of self-justification and analysis of these arguments. A complete and total waste of time. but this is what these people do to you.

It's wild. It's wild. I've had this exact same stuff before with my narcissist schizophrenic ex girlfriend. These warpings of logic and reason and having to suddenly defend yourself in some court of law.

it's like rhetorical combat. I suspect having run ins like this honed my verbal sharpness.