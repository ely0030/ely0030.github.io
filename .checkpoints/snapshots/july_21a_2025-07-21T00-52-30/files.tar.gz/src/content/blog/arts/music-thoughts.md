---
title: "music thoughts"
description: "music"
pubDate: 2025-07-13T00:00:00.000Z
pageType: "literature2"
category: "arts"
---

art pisses me off a lot. the way it's interconnected with the market you present it on.

it's nerve wracking, and unintuitive




I want to make insanely amazing art
i want no one to enjoy it but true fans who will appreciate
I want no money to be made off of it

I want it to be impactful 
not because of anything other than for its own sake.



I'm thinking of never releasing real tracks
no real releases

only releases with music videos on youtube
only shady links on instagram videos
only via CD's
only via weird sites

music sprinkled around

a new leaking culture
where the music goes to the fans

---
It's a solo activity




the music is an extension of the world you want it to be
it exists in those spaces

in those dimensions

all art is the placing of a flag on the moon, on the earth

on the spreading of the light you see in your image

all that it touches
like The Hallow

that's what it all is

from my mind to yours
or maybe not
maybe just into the world

like a fallen ruin
laying there
as someone might find it or not