#!/bin/bash

# Build the site
npm run build

# Serve the built site
npx serve dist 