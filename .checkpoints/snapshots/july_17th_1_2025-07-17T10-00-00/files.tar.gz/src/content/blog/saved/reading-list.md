---
title: "readinglist"
description: "readinglist"
pubDate: 2025-07-10
pageType: literature2
category: saved
---


# Fiction

- Stoner - John Williams
- As I Lay Dying - William Faulkner
- Blood Meridian - Cormac McCarthy
- The Metamorphosis of Prime Intellect - Roger Williams
- Permutation City - Greg Egan
- Tomorrow and Tomorrow and Tomorrow - Gabrielle Zevin
- The Man in the High Castle - Philip K. Dick
- Hocus Pocus - Kurt Vonnegut


# Non-Fiction

## Economics & Finance
- The Creature from Jekyll Island - G. Edward Griffin
- Slouching Towards Utopia: An Economic History of the Twentieth Century - J. Bradford DeLong
- The Man Who Solved the Market: How Jim Simons Launched the Quant Revolution - Gregory Zuckerman

- Lombard Street: A Description of the Money Market

## Self-Improvement
- Indistractable - Nir Eyal