---
title: "how to be hot"
description: "hot protocol"
pubDate: 2025-07-08
pageType: literature2
category: protocols
---

- sclera


## What makes me hot personally

- gaunt cheeks
- flush vibrant skin without any wrinkles or folds



#### Experience/Anecdotes

- I look really good after having went for a run usually


- I look really good when I've fasted for a day or more (not too many though)

- I look good when I'm debloated in general
(coconut water helps this, but gua sha also does)

---


### Theoretical yes, Practical maybe

- Red Light Therapy



### Practical Yes
- Gua Sha (just pressing onto my cheeks and nasolabial folds and compressing them)