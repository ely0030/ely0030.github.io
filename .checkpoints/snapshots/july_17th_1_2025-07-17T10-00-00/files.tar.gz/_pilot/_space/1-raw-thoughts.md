# NOTEPAD

*Raw thoughts have been processed and moved to priority list and old thoughts archive*

- The idea of a planning wall that clearly shows the projects I'm working on so i can plan stuff
The nice part is that I can fully visually design this virtual planning board

make it in the style of the site