claude-monitor --plan max20

claudepoint list claudepoint create --description "

claude --resume --dangerously-skip-permissions
