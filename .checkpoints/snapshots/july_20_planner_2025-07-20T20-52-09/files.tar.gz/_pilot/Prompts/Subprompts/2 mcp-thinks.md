Use parallel sub agents to work faster. First think and plan on optimally coordinating the subagents using the sequential thinking MCP to get a well thought out plan to optimise congruence, then fire them off.

The key is to plan out in advance instead of stopping and waiting after each sequence. Ultrathink and plan hard on perfecting the sub agent plans using sequential thinking.

