Please make a folder and file in @_OPS/_open where you document the next steps and create a guide for another instance of you (you're running out of context) that has all it's memory of this conversation/session wiped.

write it like you're briefing your replacement who knows nothing about this session.

It's like a ticket where we write down everything we know and tried so you can pick up where you left off.

NOTES:

* add the current date to the filename at the end (DD-MM-YYYY) and a letter (a when you first start)

* If there is already a file there about this topic/session add a letter after the date like "DD-MM-YYYYa", or b, c, etc.
