Please make a file for within the changelog folder now documenting the changes of this session.

If they are minor changes add them to the minor changelog fille.

***

CHANGELOG FOLDER:

