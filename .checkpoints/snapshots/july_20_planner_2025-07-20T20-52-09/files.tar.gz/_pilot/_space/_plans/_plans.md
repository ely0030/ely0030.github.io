the plans folder contains files where you did research to figure out how certain systems you need to alter work

It involves

1. Doing Research
1.1. Finding out which doc files are relevant in the @docs folder
1.2. Finding out which files in the codebase are relevant

2. Coming up with a plan on how to implement the systems

2.1 Checking to make sure you don't accidentally break stuff


3. Getting the plan ready for execution
- listing all the files (prepended with an @)
- giving HIGH LEVEL ASBTRACT INSTRUCTIONS along with the details.