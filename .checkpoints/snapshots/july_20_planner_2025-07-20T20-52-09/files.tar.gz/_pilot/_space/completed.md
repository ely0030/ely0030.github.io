**1. Remove blue outline on folder clicks**  
🔥🔥 · 🟢 Easy Effort  
Remove the blue outline that appears when clicking on folders to collapse/uncollapse them, including the "collapse/uncollapse all" button
