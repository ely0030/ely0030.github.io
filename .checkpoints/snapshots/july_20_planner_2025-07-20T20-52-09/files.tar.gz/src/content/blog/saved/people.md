---
title: "people"
description: "people"
pubDate: 2025-07-08T00:00:00.000Z
pageType: "literature2"
category: "saved"
---

### Zack Bia
the [powerbroker](https://www.youtube.com/watch?v=MTHfoMXdmG8)


- John Lauters