---
title: "Governance log 1"
description: "Governance log 1"
pubDate: 2025-07-16T00:00:00.000Z
pageType: "literature2"
category: "governance"
---

10:18 AM 

I'm feeling that me being alone for extended periods is really the best for me

maybe it's the ADHD, maybe it's my stressed nature

but things only really happen for me when I've been completely alone for 1 entire day to adjust



I start thinking of things in the back of my head I need to complete
I start to get calm and able to sit down and think about things
I start being able to long-term-plan
I start being able to actually relax


like when I've been out time doesn't exist and it just feels like the last 5 minutes on the timer from the moment I wake

Now I actually get some sense of a feeling that I might be able to treat myself to watching a movie.

bro it's 10:20 AM and you have the entire day left to do stuff....

but i do not feel that way at all