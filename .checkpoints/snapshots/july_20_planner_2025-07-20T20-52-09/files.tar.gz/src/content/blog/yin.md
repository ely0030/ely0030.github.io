---
title: the yin and the yang
description: Thoughts on the need for yang
pubDate: 2025-07-01
pageType: literature
---


# what gives

  Too much yin is a bad thing. 

  Too much of a good thing is a bad thing.


  I used to believe in like things like, i don't know, being a good person. I'd always think about ethics and morality. I was like 11 years old and the first time I jerked off i couldn't stop thinking about whether it was ethically just or not. I was just having this major moral philosopical crisis over beating my dick, and i don't think that ever got anywhere as i kept jorkin' it anyway.

That should give a decent example of what my brain is like and what my mind is like.

I think of Peter Thiel, this guy that studied philosophy, then got a law degree at Stanford, and finally settled on becoming an evil billionaire, ranting about the anti-christ in interviews where he gets asked about whether the mass surveillance system he's developing for-profit isn't a perfect tool to empower the anti-christ

Fine fine.

Fair enough.

But it strikes me that he did study philosophy and that he did study law and everything surrounding it. For someone to get to these conclusions by themselves would be trivially interesting, but his history and this guy's achievements make you wonder how he got to this.

---

# The yin to the yang

I used to believe in good and bad
life finds a way to let you down

you don't know about good or bad until you're forced to let someone die
and have to prepare yourself to live with it