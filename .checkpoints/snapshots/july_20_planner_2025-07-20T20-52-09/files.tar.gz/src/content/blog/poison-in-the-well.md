---
title: "poison in the well"
description: "poison in the well"
pubDate: 2025-07-16T00:00:00.000Z
pageType: "blog"
category: "cc thoughts"
---

00:49 AM
 
Opinions of the mid curve are so harmful


when striving for excellence, when trying to make early bets

you DON'T want to be around these people


how can someone be wrong with such certainty?

I'm not sure but it's impressive, and very salient to me

I put a lot of weight to conviction, and seeing something be confident about something like this is a cognitive hazard to me

"it's gotta be right if they're this sure about it right?"


boy do i have news for you