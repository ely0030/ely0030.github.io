---
title: "building muscle"
description: "how to build muscle"
pubDate: 2025-07-08T00:00:00.000Z
pageType: "literature3"
category: "uncategorized"
---

# How to build muscle

- Give the muscles a stimulus
Mechanical Tension 






### Tips & Tricks

- go slower on the eccentric
- go through out the full Range of Motion and stretch


- get animal protein instead of other sources
- get a lot of protein