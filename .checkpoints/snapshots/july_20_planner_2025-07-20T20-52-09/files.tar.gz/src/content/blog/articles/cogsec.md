---
title: "cogsec"
description: "cognitive security"
pubDate: 2025-07-13
pageType: literature2
category: articles
---

It helps to realize you're not as robust as you think.

I've had my beliefs shattered a few times
I've had them reinstated


Anyone could go insane to the extent that they have an open mind to things


when confronted with incredibly salient information, you sink to what you feel



Knowing things doesn't really matter much. When information stops being salient you're just not inclined to believe it anymore

some things can shatter you
it's always easy to be shattered

i think about this a lot

that destruction is that much easier than the construction of a thing
mostly when it's complex and intricate

as we are as biological machines