- when hovering over the name/title of a card it shouldn't show a "you can move this card around" cursor but it should show that clicking will make you edit the text/name. 
Clicking on that area will always just activate the ability to edit the text, and after the first click it should always just make you able to click on the letters and place the cursor there instead of exiting out of edit mode

- to add onto that, I cannot click or use any of the features on the card without a second click exiting the edit state. I click on a dropdown and it opens, but I can't click on any of the options as it closes the dropdown

- Moving cards around should also make it so that you can drag and drop a card at a place where another card currently is, and that they swap places
this should also be shown with some kind of intuitive minimal feedback