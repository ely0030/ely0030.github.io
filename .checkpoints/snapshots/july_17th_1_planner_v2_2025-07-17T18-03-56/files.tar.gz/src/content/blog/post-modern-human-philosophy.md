---
title: "Post Modern Human Philosophy"
description: "observation"
pubDate: 2025-07-15T00:00:00.000Z
pageType: "literature2"
category: "thoughts"
---

23:49 PM


It's a different world everything is weird 

Just learned that the roman empire, at its peak, had 75 million people living all across it. 
like a quartile living in the city parts of it as well 

Congo in africa got 100+ million there right now 

things are different 

half of the people that ever lived were born in the last century 
life is weird

things are weird 


--

I grew up on the internet
I grew up watching movies
stories from books

i saw technology emerge while I was learning the alphabet

my worldview was weird

i think in many ways i was a 21st century renaissance human
the internet empowered everything

i got on the right sites when i was younger
and met the right nerds when i was younger


and i got to reap the fruits of everything

i used to talk to this guy, this cracked schizo in hindsight really
he used to tell me about how the germans had UFO's, theories about how the structures of atoms didn't make sense, about how he coded his own game engine (which I did play test), and how him writing it in C instead of C# or C++ or whatever was the only and superior option

stuff like that

i was immersed in the entire forums
and whenever i talked to this guy, seeing as he'd get annoyed at my asking of a million questions, he just returned the mantra

"google is your friend"

and so it became


---
The next years i just spent a ton of hours on the internet
I was plugged in

I was either gaming or reading something
the forums contained everything

you learn a lot from living on the internet

there's never been such an abundance of data


such an abundance of answers



I used to have this PC, and as electronics do, stuff would go wrong at times
blue screens, weird glitches, or failures of whatever dumb software problem

things inevitably got in the way due to some form of entropy
and if you wanted to play your game or whatever it was you were doing, you had to fix it

i guess i learned everything was fixable this way
some fix existed, or maybe if you went at it long enough, it could always be fixed

writing this rn i'm realizing i got moulded into some kind of super debugger as a kid

i don't think I've ever ran into a tech problem i couldn't fix eventually

i'd just spend hours and hours, sometimes days (although it didn't feel like that at all) working on something until it magically worked again

I'm pretty sure I carried this mindset over to everything in my life really
My mindset walking around was that everything could be done if you tried hard enough
eventually

and that philosophy worked


That mindset also contained the subconscious belief that there were answers to everything
and honestly there were

maybe not directly, but the availability of data and anecdotes of people dealing with things was so vast that anything could be triangulated from those available facts

there was really nothing you were totally blind on, or so blind that you couldn't at least form some kind of skewed toy model in your of how it probably worked about


now in my 20s looking back at the history of the world, and having gained some awareness of what it's like not to have a computer (, and having met a lot of people who didn't experience the same kind of internet childhood as me) I've come to realise how unusual it all is

How this insane amount of information, and these networks of people experimenting and doing the fore-work for you on any given subject, is absolutely wild

it's insane

this massive scale of collaboration on any given subject

the internet and its hidden gardens contain a fruit to anything that somebody once imagined, and people were able to get in touch with that idea no matter where they are

mass collaboration.

and I guess i'm what happens when you give a human access to those information sources after they've been built and cultivated for a decade



I kind of maxxed everything I could get my hands on

I'd get a thing I'd want to get better at
and I just knew someone on the internet was working on it, and probably figured it out

So yeah

you become the Post Modern Human


though I don't see many other people doing this
I haven't seen anyone doing it really

I suppose there's a certain temperament you needed to have to take advantage of it

and all before it all go enshittified too

there was a sweet spot on the internet of accessibility, legacy in that the communities had time to work on and validate their theories, and a certain wild west quality to it where things weren't policed or gate kept (for better or worse).

Then imo afterwards we got this weird funnel era where the internet really only means Reddit, Twitter, Youtube, etc.

TikTok as well

it got baby-proofed.


it's funny how arriving on the internet there's like a little walkway that gets you walking right past the breadth of the entirety of all human knowledge ever conceived, and right into a some kind of algorithm engineered to get you to watch ads.