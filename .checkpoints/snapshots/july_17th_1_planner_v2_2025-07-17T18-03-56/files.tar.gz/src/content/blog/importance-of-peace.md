---
title: "importance of peace"
description: "the ultimate privilege"
pubDate: 2025-07-16T00:00:00.000Z
pageType: "literature2"
category: "thoughts"
---

00:27 AM 
 
I'm kind of astounded by the importance of peace
for me anyway

i can't get anything done if I know I'll get disturbed like that

when I know that I can't be sure I've got time to spend on anything for a determined set of time
Like, this feeling of un-safety, of being ready and bracing yourself for the off-chance you get thrown into some random situation

Like, what's the spread of unfortunateness?

Some places you can feel that the worst thing that can happen isn't that bad at all

Maybe you get reminded too much of what could go wrong in a place that feels unsafe

Nothing could ever happen, but it keeps you on edge
you can never rest getting taunted like that



I feel like that a little right now


I don't know

---
 
Anyway, i've noticed how big of a boost I get from the certainty of complete safety

i kind of lose myself in what I do

I open up like some kind of flower
or undress like a hermit crab

and that's when I'm able to get fully into something with complete disregard for any other act of survival

it's just pure thinking and immersing


---
I had this thought when I thought my ex would send some crazy schizo killer to my apartment to kill me after telling painting me in the worst light ever conceived

I had this thought after seeing 5 spiders within a week, lounging on the furniture in my apartment and between the creeks that very obviously line my ceilings

I had this thought when I felt the hoarder guy that lived here before me and had the most outrageous life experience stories with a history of violence and paranoia might've accidentally left a camera hanging here after moving out

I had this thought when my downstairs neighbour randomly knocked on my paper thin door the first time and could've heard anything I was saying (or whispering) if he'd just been standing there a little before deciding to knock

stuff like that