# CSS Spacing Pitfalls

Critical CSS traps that waste hours of debugging. Read this FIRST when spacing seems broken.

## white-space: pre-line Death Trap

**Location**: BlogPost.astro:105 (REMOVED 2025-01-04)  
**Symptom**: Unfixable vertical gaps between elements  
**Time wasted**: 2+ hours

### What happened
```css
.prose {
  white-space: pre-line; /* NEVER USE THIS */
}
```

This preserves newlines in HTML as visual space:
```html
<p>text</p>
<ul>...</ul>
```
The newline between `</p>` and `<ul>` becomes ~1em of unremovable space.

### Failed attempts
- `margin: 0 !important` - no effect
- `margin-top: -1em` - no effect  
- `position: relative; top: -0.5em` - no effect
- Modified 20+ CSS rules across multiple files

### Why it failed
Not a margin/padding issue. The browser renders the newline character as actual space, like pressing Enter in a word processor.

### Solution
Remove `white-space: pre-line`. Period.

## Astro Style Scoping Trap

**Location**: Any component `<style>` tag  
**Symptom**: Styles don't apply to child components

### What happened
```astro
<!-- BlogPost.astro -->
<style>
  body.literature2 .prose p + ul {
    margin-top: 0 !important; /* Won't work! */
  }
</style>
```

Astro scopes component styles by default. They only apply to that component's HTML.

### Solution
```astro
<style is:global>
  /* Now works everywhere */
</style>
```

## CSS Load Order Chaos

**Files**: global.css vs component styles  
**Symptom**: !important doesn't work, specificity seems broken

### What happened
Astro loads CSS unpredictably:
1. Component styles (literature2-specific)
2. Global styles (general .prose rules)

Later styles win regardless of specificity.

### Solution
- Use CSS layers: `@layer base, components`
- Or move all prose styles to ONE location
- Or use inline styles as nuclear option

## JSX/HTML Whitespace Trap

**Location**: index.astro:171 (visual markers)  
**Symptom**: CSS margins/padding have zero effect on element spacing  
**Time wasted**: 30min

### What happened
```jsx
{markStr && <span class="mark">!</span>}
<a href="#">Title</a>
```
The newline/space between `</span>` and `<a>` renders as visible space character.

### Failed attempts
- `margin-right: -1rem` - no effect
- `margin-left: 0` - no effect
- Changed CSS specificity - no effect
- Added `!important` - no effect

### Why it failed
Not a CSS issue. The whitespace IS content, like typing a space in text.

### Solution
```jsx
{markStr && <span class="mark">!</span>}<a href="#">Title</a>
```
Remove ALL whitespace between elements.

## Key Lessons

1. **Check white-space first** when margin/padding changes do nothing
2. **JSX whitespace = content** - newlines between elements create gaps
3. **Always use `is:global`** for cross-component styles in Astro
4. **CSS load order > specificity** in build tools
5. **Test in production build** - dev server lies about CSS order