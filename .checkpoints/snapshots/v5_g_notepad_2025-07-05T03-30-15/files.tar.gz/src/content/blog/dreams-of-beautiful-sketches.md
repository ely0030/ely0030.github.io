---
title: Dreams of Beautiful Sketches
description: "On the art of gathering tools and finding purpose"
pubDate: 2025-04-20
private: true
passwordHash: 8cf450e9730f83af4cc570d8ef3c4bdaa2cf02d9f2ce57f4626cec1459f55082
pageType: literature
---

# Dreams of Beautiful Sketches

I've got dreams of beautiful sketches

Get the camera  
Get the film  
Get the right film  
Get the brush  
Get the canvas  

Get the furniture

What do you live for?
