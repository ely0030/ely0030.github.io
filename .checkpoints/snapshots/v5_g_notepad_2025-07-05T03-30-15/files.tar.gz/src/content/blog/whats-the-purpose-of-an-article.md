---
title: "What's the purpose of an article?"
description: "What's the purpose of an article?"
pubDate: "2025-04-21"
private: true
passwordHash: 8cf450e9730f83af4cc570d8ef3c4bdaa2cf02d9f2ce57f4626cec1459f55082
---

What's the purpose of an article?

I'm not sure?
If they're just for me, than what do I worry about?

I'm not sure

Sometimes you just want something manifested

when you carve your name in the wall you want it to stay there
and to be there every time you return to the wall

that has some value
for some reason

site = wall

thanks 