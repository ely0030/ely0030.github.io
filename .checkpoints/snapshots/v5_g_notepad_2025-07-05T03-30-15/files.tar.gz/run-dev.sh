#!/bin/bash
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"  # This loads nvm
nvm use 18.17.1

# Auto-convert literature files from drafts folder
echo "🔄 Checking for markdown files to convert..."
node src/utils/auto-convert-literature.js
echo ""

# Start the dev server
astro dev 