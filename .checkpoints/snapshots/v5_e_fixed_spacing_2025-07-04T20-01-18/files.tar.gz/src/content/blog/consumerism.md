---
title: "consumerism"
description: "I don't think there's a need to create art"
pubDate: 2025-07-04
pageType: literature
category: articles
---

I don't think there's a need to create art

i think a lot about the joy I get from consuming art, and the anxiety of trying to figure out how it reflects on my art and what and how and if i should make that art

it's like this lobby against you

<br>
why do I need to make anything?

<br>
it's like your dad calling you lazy for not doing the dishes

<br><br>
I think consuming things is great
whether that be a movie
a great dish
or the viewing of an amazing forestscape

why do I need to make anything?

<br>
it's like getting mad at me for enjoying the fact a tree made this apple

people, things, life, just create things as they are alive

the ooze

it's what they do

who am I not to take and enjoy them

<br>
I think there's a great art in fully learning how to enjoy being alive

what's the point in creating great art if you chastise yourself over it. 

you're not that dissimilar from a machine
from a sweatshop worker in the sweatshop
from chatgpt when it gets asked to generate an image
or a factory setup churning out guitars, or anything

why do we attribute so much overhead to it?

<br>
i think there's an art to learning what's there, and fully enjoying it
to being a machine that generates joy

that right combination of dopamine and serotonin, somewhere in the brain

<br><br>
so much is put on the fact that people value and appreciate you for having made something
everybody is a narc acting like your manager

"oh you haven't made anything? What are you doing with yourself anyway"

<br>
I've been so caught up on that
but for what

i'd dedicate my life to honing a craft, and maybe i'd make the best thing within whatever ecosystem

and then what

you get the fruits of people their celebrations of you
but doesn't that mean you did it for that?

if it was for it's own sake, and that creation was really the goal, then there'd be little need to share it

then maybe it'd make sense to hoard wealth, and to commission, and to create, and to hole yourself up to make something great, or do what needs to be done if it involves putting yourself out there instead

and you'd get it made.

there.

are you happy now?

<br><br>
---
Maybe a true life is one spent in mental isolation,  without that much internalized bother from the outside world
so you'd be able to figure out what you actually want, without any of the constraint of reality imposing itself on you, witnessing it
simulating it in your own head
even when it's not there right now

<br><br>
i don't know

<br>
