# Obsidian-Style Notepad Feature Blueprint

## Overview
An interactive notepad feature that allows users to create, edit, and manage markdown notes directly in the browser with Obsidian-style inline editing. Notes are stored in localStorage and displayed in a special section on the homepage.

## Core Features

### 1. Obsidian-Style Editing
- **Click-to-edit**: Click any rendered text to instantly edit it inline
- **Live markdown rendering**: As you type `**bold**`, it renders as **bold** immediately
- **Seamless transitions**: No buttons, no escape key - just click to edit, click elsewhere to finish
- **Preserve formatting**: Maintains exact spacing, line breaks, and markdown structure

### 2. Note Management
- **Flat structure**: Simple list of notes, no folders
- **Custom titles**: Users can set meaningful titles for their notes
- **Automatic "Untitled" note**: Always available as entry point
- **Note deletion**: Simple delete functionality
- **Local storage**: All notes saved to browser localStorage

### 3. Homepage Integration
- **Special section**: Separate area on homepage for local notes
- **Visual differentiation**: Slight tint/color to distinguish from regular posts
- **Orange "Untitled" entry**: Special styling for the notepad entry point
- **Direct editing**: Clicking any local note opens it in edit mode

### 4. Distinct Page Type
- **New page type**: `notepad` with its own unique styling
- **Minimalist design**: Clean, distraction-free writing environment
- **Consistent with site**: Uses existing design tokens and patterns

## Technical Implementation

### 1. Routes & Pages
```
/notepad - Main notepad interface
/notepad/[id] - Individual note view/edit (optional, could be SPA)
```

### 2. Component Structure
```
src/
├── components/
│   ├── NotepadEditor.astro      # Main editor component
│   ├── NoteList.astro           # List of notes sidebar
│   ├── MarkdownRenderer.astro   # Live markdown rendering
│   └── EditableBlock.astro     # Obsidian-style editable blocks
├── pages/
│   └── notepad.astro            # Main notepad page
└── scripts/
    └── notepad.js               # Client-side note management
```

### 3. Data Structure
```javascript
// localStorage structure
const notes = {
  "note-id-1": {
    id: "note-id-1",
    title: "My First Note",
    content: "# Welcome\n\nThis is my first note...",
    created: "2024-01-15T10:00:00Z",
    modified: "2024-01-15T10:30:00Z"
  },
  "untitled": {
    id: "untitled",
    title: "Untitled",
    content: "",
    created: "2024-01-15T09:00:00Z",
    modified: "2024-01-15T09:00:00Z"
  }
}
```

### 4. Key Features Implementation

#### Obsidian-Style Editing
```javascript
// Pseudo-code for editable blocks
class EditableBlock {
  constructor(element) {
    this.element = element;
    this.isEditing = false;
    this.bindEvents();
  }
  
  bindEvents() {
    this.element.addEventListener('click', () => this.startEdit());
    document.addEventListener('click', (e) => {
      if (!this.element.contains(e.target) && this.isEditing) {
        this.endEdit();
      }
    });
  }
  
  startEdit() {
    this.isEditing = true;
    // Convert rendered markdown back to source
    // Show textarea with live preview
    // Position cursor at click point
  }
  
  endEdit() {
    this.isEditing = false;
    // Save to localStorage
    // Update rendered view
  }
}
```

#### Live Markdown Rendering
- Use a lightweight markdown parser (e.g., marked.js)
- Real-time preview as user types
- Support for common markdown: headers, bold, italic, links, lists, code blocks
- Preserve whitespace and line breaks exactly

#### Homepage Integration
```astro
<!-- In index.astro -->
<section class="local-notes">
  <h2>Your Notes</h2>
  <ul class="post-list">
    <li class="local-note untitled">
      <a href="/notepad">• Untitled</a>
    </li>
    {localNotes.map(note => (
      <li class="local-note">
        <a href={`/notepad#${note.id}`}>• {note.title}</a>
      </li>
    ))}
  </ul>
</section>
```

### 5. Styling Approach

#### CSS Variables for Notepad
```css
:root {
  --notepad-font-size: 16px;
  --notepad-line-height: 1.6;
  --notepad-max-width: 700px;
  --notepad-bg: #fafafa;
  --notepad-text: #333;
  --notepad-accent: #ff8c00; /* Orange */
  --notepad-tint: rgba(255, 140, 0, 0.05);
}

/* Local note styling on homepage */
.local-note {
  background: var(--notepad-tint);
  border-radius: 3px;
  padding: 2px 4px;
}

.local-note.untitled a {
  color: var(--notepad-accent);
}
```

#### Notepad Page Layout
- Minimal header (just "Home" link)
- Two-column layout: note list + editor
- Clean typography focused on readability
- Subtle interactions (no heavy animations)

### 6. User Flow

1. **Entry Point**: User clicks orange "Untitled" link on homepage
2. **Notepad Opens**: Shows list of notes on left, editor on right
3. **Click to Edit**: Click any text to start editing that block
4. **Live Preview**: Markdown renders as you type
5. **Auto-save**: Changes save to localStorage automatically
6. **Note Management**: Create new notes, rename, delete from sidebar
7. **Return Home**: Notes appear in special section on homepage

### 7. Progressive Enhancement

- **Basic functionality**: Works without JavaScript (read-only)
- **Enhanced editing**: JavaScript enables Obsidian-style editing
- **Offline capable**: All data in localStorage
- **Export option**: Download notes as .md files

### 8. Implementation Phases

#### Phase 1: Basic Infrastructure
- Create `/notepad` route
- Set up localStorage integration
- Basic note CRUD operations
- Simple markdown rendering

#### Phase 2: Obsidian-Style Editing
- Implement click-to-edit functionality
- Live markdown preview
- Seamless edit/view transitions
- Block-level editing

#### Phase 3: Homepage Integration
- Add local notes section to homepage
- Style differentiation for local notes
- Orange "Untitled" entry point
- Note count/preview

#### Phase 4: Polish & Features
- Note search functionality
- Keyboard shortcuts
- Export/import options
- Performance optimizations

## Design Decisions

1. **No folders**: Keep it simple with flat structure
2. **No authentication**: Pure client-side, no server sync
3. **Minimal UI**: Focus on writing, not chrome
4. **Standard markdown**: Use CommonMark spec
5. **Responsive**: Works on mobile devices

## Technical Considerations

1. **localStorage limits**: ~5-10MB depending on browser
2. **Performance**: Lazy load notes, virtualize long lists
3. **Data integrity**: Regular localStorage checks, corruption handling
4. **Browser compatibility**: Modern browsers only (ES6+)

## Future Enhancements

1. **Search**: Full-text search across all notes
2. **Tags**: Simple tag system for organization
3. **Templates**: Starter templates for common note types
4. **Themes**: Light/dark mode for notepad
5. **Sync**: Optional server sync (future consideration)

## Success Metrics

1. **Seamless editing**: < 50ms transition between view/edit
2. **Fast saves**: Instant localStorage writes
3. **Responsive UI**: No lag during typing
4. **Data safety**: Zero data loss scenarios
5. **Intuitive UX**: No learning curve for basic use