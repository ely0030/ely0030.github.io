---
title: saved reading
description: ---
pubDate: 2025-07-04
pageType: literature
category: saved
---
# Saved Reading
- https://paulgraham.com/charisma.html



# Concepts
- https://en.wikipedia.org/wiki/Satisficing