# CLAUDE.md - AI Assistant Context

Quick reference for AI assistants. Read this FIRST.

## Project Overview
Personal blog built with Astro. Minimalist aesthetic, multiple page types, custom features.

## Critical Files to Know
- **docs/LLM_CONTEXT.md** - Complete project documentation
- **docs/troubleshooting.md** - Common issues and solutions
- **docs/css-spacing-pitfalls.md** - CSS traps (READ if spacing seems broken)
- **src/styles/global.css** - All styling (2000+ lines)
- **src/pages/index.astro** - Homepage with folder navigation
- **src/layouts/BlogPost.astro** - Main blog layout

## Development Commands
```bash
npm run dev          # Start dev server (port 4321)
./run-dev.sh        # With auto-conversion for literature pages
npm run build       # Production build
./host.sh           # Network hosting
```

## Known Pitfalls (Avoid These!)

### 1. CSS white-space: pre-line
**NEVER** use this with prose content. Creates unfixable spacing.
- Location: BlogPost.astro:105 (removed 2025-01-04)
- Wasted 2+ hours debugging

### 2. Astro Style Scoping
Component styles are scoped by default. Use `<style is:global>` for cross-component styles.

### 3. Literature Page Line Breaks
Markdown collapses newlines. Use:
- `<br>` tags manually
- Auto-converter in `run-dev.sh`
- Never try CSS-only solutions

### 4. Folder Animation Flicker
Multiple scripts fight for control. Solution involves `body.no-transitions` class.

### 5. Notepad Editor Cursor Jumps
**NEVER** replace innerHTML while user typing. Causes cursor to jump.
- Location: notepad.astro:848-872
- Solution: Only format on blur when editor not focused
- See: docs/notepad-critical-knowledge.md

### 6. CSS Grid Column Width Mismatch
Grid template columns MUST match actual content width requirements.
- Location: notepad.astro:33-44
- Issue: 250px grid < 300px min-width = 50px overflow
- Fix: Match grid column to content needs

## Page Types
- **blog** - Standard blog post (default)
- **magazine** - Larger text, wider spacing
- **stanza** - Poetry/prose with reading progress bar
- **literature/2/3** - Dense text layouts (see warnings above)
- **book** - Paper texture effect
- **notepad** - Obsidian-style editor (see docs/notepad-critical-knowledge.md)

## Quick Wins
- Visual markers: Add `markType`, `markCount`, `markColor` to frontmatter
- Password protect: Add `private: true` and `passwordHash: 'sha256hash'`
- Categories: Add `category: "name"` (lowercase only)

## Testing Reminders
- **Always test in production build** - CSS load order differs
- **Check multiple page types** - Styles can conflict
- **Verify on mobile** - Responsive breakpoints at 768px, 1000px

## Recent Issues (2025-01-04)
- Fixed excessive spacing between paragraphs and lists
- Root cause: `white-space: pre-line` (not margin/padding)
- Solution: Remove the property entirely

## Where to Look
- **Styling issues**: src/styles/global.css (search for body.pageType)
- **Build issues**: astro.config.mjs, vite settings
- **Content issues**: src/content.config.ts for schema
- **Homepage layout**: src/pages/index.astro (folder system)
- **Notepad issues**: docs/notepad-critical-knowledge.md (MUST READ)

## Do's and Don'ts
✅ DO:
- Read error messages carefully - Astro has good diagnostics
- Use grep/search before assuming something doesn't exist
- Test CSS changes in production build
- Check docs/ folder for existing solutions

❌ DON'T:
- Use `white-space: pre-line` with prose
- Forget `is:global` on component styles
- Try to preserve markdown line breaks with CSS
- Assume dev server CSS order matches production

## Need More Context?
Start with `docs/LLM_CONTEXT.md` for complete details.