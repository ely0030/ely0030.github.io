# Notepad Implementation: Critical Knowledge

## Failure Modes & Fixes

### 1. Map vs Object Confusion
**Location**: `src/pages/notepad.astro:643-830`
**Issue**: Refactored code used Map but methods treated it as Object
**Fix**: Use `this.notes.get(id)` not `this.notes[id]`, `Array.from(this.notes.keys())` not `Object.keys(this.notes)`

### 2. Storage Config Access
**Location**: `src/pages/notepad.astro:395-397`
**Issue**: `getAllNoteIds()` tried `this.config.defaults.untitledId` but storage only has `this.config` not full NOTEPAD_CONFIG
**Fix**: Hardcoded 'untitled' since it's constant

### 3. Missing init() Call
**Location**: `src/pages/notepad.astro:929-930`
**Issue**: Constructor didn't call init(), app never started
**Fix**: `const app = new NotepadApp(); app.init();`

## Non-Obvious Dependencies

### localStorage Keys Pattern
**Must follow**: `prefix:identifier` format
- Notes: `notepad:note-{id}`
- Index: `notepad:index`
- Folders: `folder-${categoryId}`
**Why**: Site-wide convention for key namespacing

### Static Site Constraints
**Location**: `astro.config.mjs` - `output: 'static'`
**Impact**: Can't use dynamic routes like `/notepad/[id]`
**Solution**: Hash routing `/notepad#note-id`

### Apache Index Integration
**Location**: `src/pages/index.astro:172-197`
**Structure Required**:
```html
<div class="folder-group" data-category="...">
  <div class="directory-entry">...</div>
  <div class="post-list">...</div>
</div>
```
**Why**: Existing folder toggle JS expects this exact structure

### Note Sidebar Display
**Location**: `src/pages/notepad.astro:690-739`
**Critical**: Notes must be `<a>` tags, not spans, to look clickable
**Hash Navigation**: Homepage links use `/notepad#note-id`

## Cursor Jump Prevention (CRITICAL)

### Root Cause
**Location**: `src/pages/notepad.astro:848-872`
**NEVER**: Replace innerHTML while user is typing - destroys cursor position
**ALWAYS**: Format only on blur or when editor not focused

### Failed Approaches (DO NOT RETRY)
1. **Cursor save/restore with offset calculations** - Too complex, unreliable
2. **DOM manipulation on every keystroke** - Causes cursor jumps
3. **contentEditable='plaintext-only' with overlay** - Can't do inline formatting
4. **Debounced formatting while typing** - Still causes jumps

### Working Solution
**Location**: `src/pages/notepad.astro:848-852`
```javascript
const isFocused = document.activeElement === editor;
if (isFocused) return; // CRITICAL: Skip formatting while typing
```

### Text Extraction
**Location**: `src/pages/notepad.astro:835-836`
**Use**: `editor.innerText` for contentEditable (preserves newlines)
**NOT**: Complex TreeWalker approaches

## CSS Pitfalls

### Never Use white-space: pre-line
**Location**: Removed from `src/layouts/BlogPost.astro:105`
**Why**: Creates unfixable spacing issues with prose
**Alternative**: Use `<br>` tags or proper markdown parsing

### Body Class Scoping
**Location**: `src/styles/global.css:2403-2429`
**Pattern**: All notepad styles must be under `body.notepad`
**Why**: Prevents conflicts with other page types

## Build/Dev Considerations

### Node Version Lock
**Location**: `.nvmrc` - `18.17.1`
**Critical**: Use `nvm use` before dev/build

### Vite Build Size
**Impact**: Monaco editor would add ~2MB
**Solution**: Custom contentEditable implementation (~11KB total)

## Data Migration Risk

### Note Structure Change
**Old**: `{ blocks: [{id, content}] }`
**New**: `{ content: string }`
**Risk**: Existing notes won't load after update
**Mitigation**: Add migration logic in loadNotes() if needed

## Layout Conflicts (CRITICAL)

### Grid Column Width Mismatch
**Location**: `src/pages/notepad.astro:33-44`
**Issue**: Grid allocated 250px but sidebar had min-width:300px - caused 50px overflow into editor
**Symptom**: "jammed" or "clashing" appearance between sidebar and editor
**Fix**: `grid-template-columns: 300px 1fr` and `gap: 2em`
**LESSON**: Grid column width MUST match actual content requirements

## Feature Changes

### Homepage Integration (REMOVED)
**Old**: Separate "Local Notes" folder with orange styling
**New**: Single "Untitled" entry in uncategorized folder (dated July 5, 2025)
**Location**: `src/pages/index.astro:84-102`
**Why**: Make notepad innocuous/hidden

### Preview Feature (REMOVED)
**Removed**: Preview button, togglePreview(), Ctrl+P shortcut
**Location**: `src/pages/notepad.astro` - multiple deletions
**Why**: Simplify, focus on pure writing