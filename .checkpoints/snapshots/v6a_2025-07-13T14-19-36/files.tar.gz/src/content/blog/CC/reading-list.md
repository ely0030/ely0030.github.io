---
title: "CC saved tweets"
description: "readinglist"
pubDate: 2025-07-12
pageType: literature2
category: CC
---


- https://x.com/insiliconot/status/1943640278696394958



# Keep a Trading Journal
- https://x.com/0xdetweiler/status/1943599803943764018