---
title: "building muscle"
description: "how to build muscle"
pubDate: 2025-07-08
pageType: literature3
Category: protocols
---

# How to build muscle

- Gives the muscles a stimulus
Mechanical Tension 






### Tips & Tricks

- go slower on the eccentric
- go through out the full Range of Motion and stretch


- get animal protein instead of other sources
- get a lot of protein