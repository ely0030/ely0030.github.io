---
title: "ideas"
description: "ideas"
pubDate: 2025-07-03
pageType: literature2
---

- vids of my cat with Future playing in the background