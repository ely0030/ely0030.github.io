---
title: saved reading
description: ---
pubDate: 2025-07-04
pageType: literature
category: saved
---
# Saved Reading
- https://paulgraham.com/charisma.html



# Concepts
- https://en.wikipedia.org/wiki/Satisficing





### Nice Articles
- https://modernhomesla.blogspot.com/2014/08/domed-silvertop-john-lautners-reiner.html