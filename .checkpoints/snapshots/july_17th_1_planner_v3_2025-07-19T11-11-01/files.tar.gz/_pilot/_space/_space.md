The idea of the _space folder is to get the raw thoughts in 1-raw-thoughts.md and get Claude Code to think about them and structure them, rating them by ease of implementation and impact (giving each task/feature request a score)

this way I can get all thoughts in there as low friction as possible
and you can then do the forework on the planning a little bit.



---

NOTES:
- 