



- make the planning wall's home/about thingy the same as the notepad: A thing that says Parent directory