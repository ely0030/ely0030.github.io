---
title: "Horse Players"
description: "I'm starting to feel microcaps is more like betting on horses than investing."
pubDate: 2025-07-03
pageType: literature3
category: articles
---

### Microcaps and Horse Betting

I'm starting to feel microcaps is more like betting on horses than investing.
maybe that's what investing is

<br>

My process always used to be:
1. look at a million coins
2. pick out the ones that aren't total shit

and basically that'd be the core of it.

<br>
of course there were a ton of tiny factors that i'd take into account, but the big picture basically came down to that.

If you found anything that wasn't a steaming pile of shit with a marketcap under 5 million, you'd basically have a good, early bet.

<br>

## The Psychology of Belief

Personally I believed in this process as well. I used to think that these companies had interesting products, and that they were massively undervalued, and that they couldn't wait to blow up and 10x their marketcap,

and this **is** why it worked

<br>
because we all believe that, fullporting our fiat into the coin

<br>
ofc, back in the day I didn't know that this was the **sole** mechanism that really dictated the price action of the coin
and that it wasn't as much about the actual coin, product, or team, but the psychology of the FOMO fever sparking over into each and every buyer that met eyes with anything related to the coin.

it's all psychology, and I was really good at knowing when I was starting to get this feeling.

in a way i was the indicator, and i was very well attuned.

<br>

## The Core Mechanics

Yeah, at the end of the day it really comes down to "will people want to buy this?" (which translates into the buying obv)

and that then came down to "will people think this will be worth more than they'll buy it for?" (and very imminently, ideally)

<br>

## The Microcap Appeal

microcaps just scratched this itch on multiple levels:
1. the marketcap number was so tiny it instantly meant undervalued
2. the coin's liquidity was likely so low that it only takes **very** little to pump the price (no need for the million dollar injections)
3. there's a long way up until anybody's thinking about taking profit

<br>
This is the concept of the casino basically.

<br>

## The Evolution to Memecoins

So, my thinking is, this is basically not that different from a meme coin. The only difference is that the "memetic" qualities that got people excited about a microcap ("fundamentals") were things like tech (1 gazillion transactions per second!!!!!), the team (Vitalik's mom is on the project!!!*), or anything else that was novel or unique about it.

The hope and the dream and the greed were the actual core drivers of the increase.

<br>
Now in 2025, I feel that memecoins realized they don't even need any of the fundamentals to do this anymore. It's just pure psychological value assessment.

pure psychology of "I buy this now because it will go up afterwards". And in it's essence it's very pure.

<br>
Do i understand how the hell it works? 

not at all.
not yet anyway.

<br>

## Full Circle: Back to Horse Betting

But,

it's always been this way in that you just pick a horse to bet on.

<br>
The horses changed though

I don't have a metaphor on this yet..

<br>
but everyone just bets on a horse they think will win,
and though everything's changed it does still come down to that.

<br>
Now how people come to a consensus on what horse wins and what doesn't still puzzles the shit out of me.

<br>

*(actual coin I invested in that went 30x)