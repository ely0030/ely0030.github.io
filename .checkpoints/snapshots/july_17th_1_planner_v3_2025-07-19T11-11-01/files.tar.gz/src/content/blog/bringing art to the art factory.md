---
title: bringing art to the art factory
description: You only have to look online a little and you're faced with the fact that there is great art getting made all the time, everywhere
pubDate: 2025-07-02
pageType: literature2
---

You only have to look online a little and you're faced with the fact that there is great art getting made all the time, everywhere

<br><br>
i guess it's just weird to look online and see people creating the things you would like to see created, non-stop.

why would i put in the effort when it's already getting made?

i don't think i can add anything to that
and i if could, i think it would become too much of a quirk-fest being so focused trying to be different.

<br><br>
i can't help but wonder what the point of uploading art is

we've created this like mass marketplace where millions of people get incentivised to up their game a little to match and supersede the apex art pieces they see on their feeds

which is great
great art has never been more in abundance and available for consumption to any average joe

it's awesome

but it's weird

<br><br>
even if you managed to be picasso 2, there's a big big big biiig chance you would not really get picked up or acknowledged by any of the kingmakers

Maybe that's just my opinion, but it's become clear to me that all great artists were brands in a way. In the pre-commercial pre-capitalist sense, in that everything carries an identity and a hype.

Jesus is a brand for example, 

(If you didn't jolt seeing the orthodox religion-y and post-capitalist coca cola-y connotations put next to each other)

<br>
Warhol knew

it's in that all things become/are brands whether they like or not.
i should use another word,

whether you like it or not, your abilities add to your image/your branding/your aura/your myth

and you could either be unaware of this and be naturally awesome (by stumbling into glory by chance)
or you could be like Warhol and turn that awareness into obsession, and that obsession into deeper awareness of how the gears turn, and then turn the gears yourself

like i'm pretty sure he did

but i digress

<br><br>
It just makes me wonder what I'm doing here

they told me to come
so
i came to the venue
i get out there car

and the moment i walk inside with my painting i see that everybody is there with their paintings

and i feel like an oompa loompa at the art factory for making art

<br><br><br>
and i see people making stuff exactly similar to mine
and i see people making stuff thats even better than mine
and I see a LOT of people like this

so what am i doing here

<br>
that's how I feel

and then maybe I have an idea
but then I see people who have great ideas that I like as well walking the halls here

and they kind of get treated exactly like me
in that it didn't really make much of a dent in whether people noticed or cared much more than giving a follow or a like

<br><br>
i think the only thing that can be gained from sharing your art is that it resonates with people and they get out of it what you got out of the art you loved yourself

i don't see any other reason

or

to clout farm. sorry, just being realistic

<br>
if you enter the competition while acting like you don't care about winning then you're either in denial, naive, or annoying

this will cause offense to people but, man. really?
what are you doing on the validation platform then ????

ok it's for your friends, fine
but if it's more than that don't fool yourself

i'm not even saying it's wrong, it's more that the lack of honesty feels disingenuine

ofc don't listen to me and get too meta because you might find yourself uncomfortable with having to hide that truth consciously know

-
I don't get why i make art anymore

I mean it's fun and it's nice, but what is the point when i can get something that gets me and is spot on for a feeling i would try to capture 90% of the time..

that 10% is what you should create for, but still, 
then why would i show it to anyone online?

it still feels like bringing art to the art factory

<br><br>
maybe I am overthinking this. maybe it's like most things in life, in that you shouldn't look around too much 

the magic's gone when you know where it goes, and how it works, and what's going on

some things should be kept local.
let me win my local competition
don't tell me about the army of olympic athletes that could beat be in a heartbeat

<br><br>
i can't help but be aware of the marketplace
be aware of the fact that the factory is out there somewhere

running its machines silently

<br><br>
i think it takes active effort to turn a blind eye to that, and to the part within yourself that senses the game you now take part in when creating something

i use it don't i?
i check the feed
i send the likes
i follow the artists

and i praise the art i love and i loathe the art i don't

then when I make my own i'm supposed to act like other people won't run me by the same process?

<br><br><br>
related articles:

[Algorithm Hacking and World Scaping](ely0030.xyz/algorithm-world-scape)

a love for the game

<br><br>
EDIT:
so ironically i put this article into multiple LLMs and they basically all told me the subject i'm talking about is overdone and too saturated:

"it's honest and emotionally authentic, but many ppl (esp online creators) have written variations on this "what's the point when so much great stuff already exists???" existential dread."

who would've thought