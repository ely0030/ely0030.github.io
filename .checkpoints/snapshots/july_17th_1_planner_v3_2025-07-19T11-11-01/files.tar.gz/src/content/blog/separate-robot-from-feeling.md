---
layout: "../../layouts/BookPage.astro"
title: "Separate Robot from Feeling"
description: "Thoughts on separating the technical (factory) process from the creative process in music production."
pubDate: "2025-05-28"
photocopy: true
perspective: true
---

# Separate Robot from Feeling

<section>

so i hate mixing
anyway
I feel you should strive very hard from keeping the factory process separate from the creativity process
it's like designing a car, and driving a car
you don't do both at the same time
it's different things

</section>

<section>

Maybe that's why it's impressive when people can do both
I believe minds contain neural networks (needs citation...), and the better you get at something the better a specific neural network has gotten at learning to do it.
to continue the metaphor,
some neural networks require a weakening of another neural network to work more effectively
to continue the metaphor,
some neural networks require a weakening of another neural network to work more effectively
you can't learn to "let go" and simultaneously clench your cheeks harder than ever

</section>

<section>

I mean you could, but it's very hard and finnicky
kinda like having your hand outstretched and then making a fist with only your index finger
i mean i guess you could, but the difficulty of not bringing along the surrounding fingers is pretty unintuitive
if you want to make a fist, why not bring along all the fingers?
if you want to straighten out your hand, why not bring along all the fingers?
you might see the metaphor

</section>

<section>

anyway,
this is how i feel about fucking the fucking mixing process
i get there, i'm ready to make some music, to feel like an emotion or something
and then someone hands me a massive fucking 1940s Alan Turing style calculator, and asks me to turn 100 knobs to get the sound of my voice to sound like it does in real life
...
what?

</section>

<section>

okay, fine
i sit down and put on my reading glasses to look at the knobs i'm turning, and like after maybe, 5 min, i finally have a mixing chain.
ok no wait actually,
halfway through i had to grab the "mixing handbook", open it up, look in the index to identify the [vocal chain] chapter, turn the page to page 233, and then
read the information
yes

</section>

<section>

i'm sitting down and i'm looking into a book with hundreds of little letters, and i'm trying to get the answer for how to get a sine wave to hit my ears in exactly the right way for it to produce a sound that's pleasing.
i mean you'd probably call it singing (how many knob turns to get those words to my ears..), but this is the best and most comprehensive book, and, seeing as it's a delicate and highly methodical process, it's vital to use terms that help approximate things exactly how they are for the reader.

</section>

<section>

so okay i'm reading
i'm reading the vocal chain knowledge
i look at it, i focus, i absorb the information
and then i'm ready to look up at the one hundred knob panel again
okay, yes
let's turn these knobs
wait,
i missed something.

</section>

<section>

I open the book again and I read:
"most importantly make sure the singer is comfortable and able to express themselves"
i nod in agreement
before accidentally bumping into the mic stand, which then doesn't fall, but bumps into something else (600 dollar keyboard), which then doesn't get damaged itself but causes 13 xlr cables hanging around me to tighten up, and kind of infringe on my personal space a little bit
oops

</section>

<section>

anyway,
i look at the passage again and mumble, "so true", to myself as i get ready to move to the page that has the answers to my emotioned sine wave question (how do i make someone cry when they listen to my music)

</section>

## Conclusion

<section>

ok i got distracted
anyway, my point was
You shouldn't confuse two entirely different process for being part of the same pipeline
it's like building a swimming pool in your bathing suit
like
okay
okay
where is your hard hat?

</section>